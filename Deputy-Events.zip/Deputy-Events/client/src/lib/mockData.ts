import rockConcert from '@assets/stock_images/rock_concert_energy__cc8cddb1.jpg';
import iceShow from '@assets/stock_images/spectacular_ice_show_78c19301.jpg';
import festival from '@assets/stock_images/huge_music_festival__27b41a1e.jpg';
import jazzConcert from '@assets/stock_images/jazz_concert_intimat_b19791b4.jpg';

export interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  venue: string;
  priceRange: string;
  image: string;
  category: 'Concert' | 'Show' | 'Festival';
}

export const events: Event[] = [
  {
    id: '1',
    title: 'Rock Evolution: Live',
    date: '24 Октября 2024',
    time: '20:00',
    venue: 'Arena Hall',
    priceRange: '1500 - 5000 ₽',
    image: rockConcert,
    category: 'Concert'
  },
  {
    id: '2',
    title: 'Ледовое Шоу: Мелодия Льда',
    date: '05 Ноября 2024',
    time: '19:00',
    venue: 'Ice Palace',
    priceRange: '2000 - 7000 ₽',
    image: iceShow,
    category: 'Show'
  },
  {
    id: '3',
    title: 'Jazz Night: Midnight Blue',
    date: '15 Ноября 2024',
    time: '21:00',
    venue: 'Jazz Club',
    priceRange: '1200 - 3500 ₽',
    image: jazzConcert,
    category: 'Concert'
  },
  {
    id: '4',
    title: 'Summer Music Festival',
    date: '10 Декабря 2024',
    time: '14:00',
    venue: 'City Park Stage',
    priceRange: '3000 - 9000 ₽',
    image: festival,
    category: 'Festival'
  }
];
