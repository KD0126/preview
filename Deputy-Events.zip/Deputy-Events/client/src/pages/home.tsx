import { motion } from "framer-motion";
import { Link } from "wouter";
import Layout from "@/components/layout";
import { events } from "@/lib/mockData";
import { Calendar, MapPin, Ticket } from "lucide-react";
import heroBg from "@assets/stock_images/vibrant_music_festiv_cdfb5c50.jpg";

export default function Home() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={heroBg} 
            alt="Concert Crowd" 
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
        </div>
        
        <div className="w-full relative z-10 px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="flex flex-col items-center justify-center text-center mx-auto"
          >
            <h1 className="text-4xl md:text-5xl font-heading font-bold mb-6 tracking-tight leading-tight text-white uppercase">
              ВАШ БИЛЕТ В МИР <br />
              ЯРКИХ ЭМОЦИЙ
            </h1>
            <p className="text-base md:text-lg text-muted-foreground max-w-xl mx-auto mb-10 font-light tracking-wide">
              Откройте для себя лучшие культурные события города.
            </p>
            <a 
              href="#events" 
              className="inline-flex items-center justify-center gap-2 border border-white/20 hover:border-white/40 hover:bg-white/5 text-white px-8 py-3 rounded-sm font-medium text-sm uppercase tracking-widest transition-all w-fit"
            >
              Выбрать мероприятие
            </a>
          </motion.div>
        </div>
      </section>

      {/* Events Catalog */}
      <section id="events" className="py-24 relative">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center md:items-end justify-between mb-12 gap-6 text-center md:text-left">
            <div>
              <h2 className="text-3xl md:text-4xl font-heading font-bold mb-2">Афиша Мероприятий</h2>
              <p className="text-muted-foreground">Выберите событие по душе</p>
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              {['Все', 'Концерты', 'Шоу', 'Фестивали'].map((filter, i) => (
                <button 
                  key={filter}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${i === 0 ? 'bg-white text-black' : 'bg-secondary hover:bg-secondary/80 text-white'}`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {events.map((event, index) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group relative bg-card border border-white/5 rounded-2xl overflow-hidden hover:border-primary/50 transition-colors"
              >
                <div className="aspect-[3/4] overflow-hidden relative">
                  <img 
                    src={event.image} 
                    alt={event.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />
                  
                  <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold border border-white/10">
                    {event.category}
                  </div>
                </div>

                <div className="absolute bottom-0 left-0 right-0 p-6 pt-12 bg-gradient-to-t from-background via-background/90 to-transparent">
                  <div className="text-primary text-sm font-bold mb-2 flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    {event.date} • {event.time}
                  </div>
                  <h3 className="text-xl font-bold font-heading leading-tight mb-2 group-hover:text-primary transition-colors">
                    {event.title}
                  </h3>
                  <div className="text-muted-foreground text-sm mb-4 flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    {event.venue}
                  </div>
                  
                  <div className="flex items-center justify-between mt-4">
                    <span className="font-bold text-lg">{event.priceRange}</span>
                    <Link href={`/event/${event.id}/seats`}>
                      <a className="bg-white text-black hover:bg-primary hover:text-white px-4 py-2 rounded-lg font-bold text-sm transition-colors">
                        Купить билет
                      </a>
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
    </Layout>
  );
}
