import { useState } from "react";
import { useRoute } from "wouter";
import { events } from "@/lib/mockData";
import Layout from "@/components/layout";
import { ChevronLeft, Info, Check, Ticket } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

// Generate mock seats
const ROWS = 8;
const SEATS_PER_ROW = 12;

interface Seat {
  id: string;
  row: number;
  number: number;
  price: number;
  status: 'available' | 'occupied' | 'selected';
  tier: 'standard' | 'vip' | 'premium';
}

const generateSeats = () => {
  const seats: Seat[] = [];
  for (let r = 1; r <= ROWS; r++) {
    for (let s = 1; s <= SEATS_PER_ROW; s++) {
      let tier: Seat['tier'] = 'standard';
      let price = 1500;
      
      if (r <= 2) {
        tier = 'vip';
        price = 5000;
      } else if (r <= 5) {
        tier = 'premium';
        price = 3000;
      }

      // Randomly occupy some seats
      const status = Math.random() > 0.8 ? 'occupied' : 'available';

      seats.push({
        id: `r${r}-s${s}`,
        row: r,
        number: s,
        price,
        status,
        tier
      });
    }
  }
  return seats;
};

export default function SeatMap() {
  const [match, params] = useRoute("/event/:id/seats");
  const event = events.find(e => e.id === params?.id);
  const [seats, setSeats] = useState<Seat[]>(generateSeats());
  const { toast } = useToast();

  if (!event) return <div>Event not found</div>;

  const toggleSeat = (seatId: string) => {
    setSeats(current => current.map(seat => {
      if (seat.id !== seatId) return seat;
      if (seat.status === 'occupied') return seat;
      
      const newStatus = seat.status === 'selected' ? 'available' : 'selected';
      return { ...seat, status: newStatus };
    }));
  };

  const selectedSeats = seats.filter(s => s.status === 'selected');
  const totalPrice = selectedSeats.reduce((sum, s) => sum + s.price, 0);

  const handleBuy = () => {
    toast({
      title: "Билеты забронированы!",
      description: `Вы выбрали ${selectedSeats.length} мест на сумму ${totalPrice} ₽.`,
    });
  };

  return (
    <Layout>
      <div className="min-h-screen bg-background pb-20">
        {/* Header */}
        <div className="bg-secondary/50 border-b border-white/5 py-8">
          <div className="container mx-auto px-4">
            <Link href="/">
              <a className="inline-flex items-center gap-2 text-muted-foreground hover:text-white mb-6 transition-colors">
                <ChevronLeft className="w-4 h-4" />
                Назад к афише
              </a>
            </Link>
            <h1 className="text-3xl md:text-4xl font-heading font-bold mb-2">{event.title}</h1>
            <p className="text-muted-foreground">{event.date} • {event.venue}</p>
          </div>
        </div>

        <div className="container mx-auto px-4 mt-8 grid lg:grid-cols-3 gap-8">
          {/* Seat Map */}
          <div className="lg:col-span-2 bg-card border border-white/5 rounded-2xl p-8 relative overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/5 via-transparent to-transparent opacity-50" />
            
            {/* Screen/Stage */}
            <div className="mb-12 relative z-10">
              <div className="w-full h-12 bg-gradient-to-b from-primary/20 to-transparent rounded-t-[50%] border-t-4 border-primary/50 shadow-[0_-10px_30px_rgba(124,58,237,0.3)] mb-4" />
              <p className="text-center text-sm text-muted-foreground font-medium tracking-widest uppercase">Сцена</p>
            </div>

            {/* Grid */}
            <div className="grid gap-4 max-w-2xl mx-auto relative z-10">
              {Array.from({ length: ROWS }).map((_, rowIndex) => {
                const rowSeats = seats.filter(s => s.row === rowIndex + 1);
                return (
                  <div key={rowIndex} className="flex justify-center gap-2">
                    {rowSeats.map((seat) => (
                      <button
                        key={seat.id}
                        onClick={() => toggleSeat(seat.id)}
                        disabled={seat.status === 'occupied'}
                        className={`
                          w-8 h-8 md:w-10 md:h-10 rounded-t-lg md:rounded-t-xl text-[10px] flex items-center justify-center transition-all duration-200
                          ${seat.status === 'occupied' ? 'bg-white/5 text-white/20 cursor-not-allowed' : ''}
                          ${seat.status === 'available' && seat.tier === 'standard' ? 'bg-secondary hover:bg-primary/50 text-white/70' : ''}
                          ${seat.status === 'available' && seat.tier === 'premium' ? 'bg-purple-900/40 hover:bg-purple-600 border border-purple-500/30 text-purple-200' : ''}
                          ${seat.status === 'available' && seat.tier === 'vip' ? 'bg-yellow-500/10 hover:bg-yellow-500 border border-yellow-500/50 text-yellow-500' : ''}
                          ${seat.status === 'selected' ? 'bg-primary text-white shadow-[0_0_15px_rgba(124,58,237,0.6)] scale-110 z-10 transform -translate-y-1' : ''}
                        `}
                      >
                        {seat.number}
                      </button>
                    ))}
                  </div>
                );
              })}
            </div>

            {/* Legend */}
            <div className="mt-12 flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-secondary" />
                <span>Свободно</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-white/5" />
                <span>Занято</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-primary shadow-[0_0_10px_rgba(124,58,237,0.5)]" />
                <span>Выбрано</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-yellow-500/20 border border-yellow-500/50" />
                <span>VIP</span>
              </div>
            </div>
          </div>

          {/* Sidebar / Checkout */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 bg-card border border-white/5 rounded-2xl p-6 shadow-xl">
              <h3 className="font-heading font-bold text-xl mb-6 flex items-center gap-2">
                <Ticket className="w-5 h-5 text-primary" />
                Ваш заказ
              </h3>

              {selectedSeats.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground border-2 border-dashed border-white/5 rounded-xl">
                  <p>Выберите места на схеме</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="max-h-60 overflow-y-auto space-y-2 pr-2">
                    {selectedSeats.map(seat => (
                      <motion.div 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        key={seat.id} 
                        className="flex justify-between items-center bg-secondary/50 p-3 rounded-lg"
                      >
                        <div>
                          <p className="font-bold text-sm">Ряд {seat.row}, Место {seat.number}</p>
                          <p className="text-xs text-muted-foreground uppercase">{seat.tier}</p>
                        </div>
                        <span className="font-mono font-medium">{seat.price} ₽</span>
                      </motion.div>
                    ))}
                  </div>
                  
                  <div className="border-t border-white/10 pt-4 mt-4">
                    <div className="flex justify-between items-end mb-6">
                      <span className="text-muted-foreground">Итого:</span>
                      <span className="text-3xl font-bold text-primary">{totalPrice} ₽</span>
                    </div>
                    
                    <button 
                      onClick={handleBuy}
                      className="w-full bg-white text-black hover:bg-gray-200 font-bold py-4 rounded-xl transition-colors flex items-center justify-center gap-2"
                    >
                      <Check className="w-5 h-5" />
                      Купить билеты
                    </button>
                    <p className="text-xs text-center text-muted-foreground mt-3">
                      Нажимая кнопку, вы соглашаетесь с условиями оферты
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
