import { Link } from "wouter";
import { Mic2, Ticket, MapPin, Phone, Mail } from "lucide-react";

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans selection:bg-primary selection:text-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 w-full border-b border-white/5 bg-background/30 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/">
            <a className="flex items-center group cursor-pointer">
              <span className="font-heading font-black text-sm tracking-tight text-white group-hover:text-primary transition-colors whitespace-nowrap uppercase">
                DEPUTY ENTERTAINMENT
              </span>
            </a>
          </Link>

          <div className="flex items-center gap-4">
            <a href="#events" className="text-sm font-medium hover:text-primary transition-colors">Афиша</a>
            <a href="#contact" className="text-sm font-medium hover:text-primary transition-colors">Контакты</a>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-black py-12 border-t border-white/10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center text-center gap-8 mb-8">
            <div id="contact" className="w-full flex justify-center">
              <div className="w-fit text-center">
                <h4 className="font-bold mb-4 uppercase tracking-widest text-sm">Контакты</h4>
                <ul className="flex flex-col gap-4 text-sm text-muted-foreground">
                  <li className="whitespace-nowrap">+7 (916) 8877880</li>
                  <li className="whitespace-nowrap">info@deputy-entertainment.ru</li>
                  <li className="whitespace-nowrap">Москва, ул. Арбат, 1</li>
                </ul>
              </div>
            </div>
            
            <div className="max-w-2xl">
              <h3 className="font-heading text-xl font-bold mb-4 uppercase tracking-tighter block">DEPUTY ENTERTAINMENT</h3>
              <p className="text-muted-foreground text-sm block">
                — Ваш проводник в мир лучших развлечений. —
              </p>
              <p className="text-muted-foreground text-sm block font-bold mt-1">
                Концерты, шоу и фестивали — всё в одном месте.
              </p>
            </div>
          </div>
          <div className="border-t border-white/10 pt-8 text-center text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} DEPUTY ENTERTAINMENT. Все права защищены.
          </div>
        </div>
      </footer>
    </div>
  );
}
